def sum(y: int, x: int):
    return y*x

print(sum(5,6))
print(sum(90988,5))

print(sum(7,9))
